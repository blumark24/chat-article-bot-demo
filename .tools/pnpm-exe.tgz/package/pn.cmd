@echo off
pnpm %*
