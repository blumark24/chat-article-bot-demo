pnpm @args
